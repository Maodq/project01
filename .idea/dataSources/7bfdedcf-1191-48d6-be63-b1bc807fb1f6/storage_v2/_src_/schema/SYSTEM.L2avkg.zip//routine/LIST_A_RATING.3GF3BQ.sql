create PROCEDURE list_a_rating(in_rating IN NUMBER)
AS
 matching_title VARCHAR2(50);
 TYPE my_cursor IS REF CURSOR;
 the_cursor my_cursor;
BEGIN
 OPEN the_cursor FOR 'SELECT title FROM books WHERE rating = :in_rating'
USING in_rating;
 DBMS_OUTPUT.PUT_LINE('All books with a rating of ' || in_rating || ':');
 LOOP
 FETCH the_cursor INTO matching_title;
 EXIT WHEN the_cursor%NOTFOUND;
 DBMS_OUTPUT.PUT_LINE(matching_title);
 END LOOP;
 CLOSE the_cursor;
END list_a_rating;
/

