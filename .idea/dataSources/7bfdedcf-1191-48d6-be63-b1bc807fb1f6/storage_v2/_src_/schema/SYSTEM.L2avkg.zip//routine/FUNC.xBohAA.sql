create function func(no in student.sno%type) return number
is
  avg_grade number;
begin
  select avg(grade) into avg_grade from sc where sno=no;
  return(avg_grade);
end func;
/

