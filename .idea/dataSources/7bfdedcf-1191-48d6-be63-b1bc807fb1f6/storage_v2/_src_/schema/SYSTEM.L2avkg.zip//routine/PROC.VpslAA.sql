create procedure proc
(no in student.sno%type,avg_grade out number)
is
begin
  select avg(sc.grade) into avg_grade from sc where sno="9512101";
end;
/

