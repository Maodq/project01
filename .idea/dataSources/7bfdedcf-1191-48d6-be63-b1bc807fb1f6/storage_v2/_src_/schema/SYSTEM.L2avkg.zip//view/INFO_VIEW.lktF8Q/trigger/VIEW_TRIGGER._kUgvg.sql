create trigger VIEW_TRIGGER
  instead of insert
  on INFO_VIEW
  for each row
declare
n int;
begin
  select count(*) into n from student where sno=:new.sno;
  if n=0 then
    insert into student values(:new.sno,:new.sname);
    select count(*) into n from course where cno=:new.cno;
  if n=0 then
    insert into course values(:new.cno,:new.cname);
  insert into sc values(:new.sno,:new.cno,:new.grade);
end;

insert into info_view values('9521234','张三','8','科学',0);
    /

