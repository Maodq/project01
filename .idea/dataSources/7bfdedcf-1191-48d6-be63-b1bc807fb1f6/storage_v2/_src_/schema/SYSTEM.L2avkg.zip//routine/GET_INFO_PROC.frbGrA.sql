create PROCEDURE get_info_proc
  ( p_sno student.sno%TYPE,
    p_sname OUT student.sname%TYPE,
    sc_cursor OUT sys_refcursor
  )
AS

BEGIN
  SELECT sname INTO p_sname FROM student WHERE student.sno = p_sno;
  OPEN sc_cursor FOR SELECT * FROM sc WHERE sc.sno = p_sno;
END;
/

