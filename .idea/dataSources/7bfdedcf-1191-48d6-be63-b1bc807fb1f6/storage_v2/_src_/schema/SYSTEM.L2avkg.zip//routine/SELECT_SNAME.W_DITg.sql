create PROCEDURE select_sname(p_sno IN student.sno%TYPE, p_sname OUT student.sname%TYPE)
AS

BEGIN
  SELECT sname INTO p_sname FROM student WHERE sno = p_sno;
END;
/

