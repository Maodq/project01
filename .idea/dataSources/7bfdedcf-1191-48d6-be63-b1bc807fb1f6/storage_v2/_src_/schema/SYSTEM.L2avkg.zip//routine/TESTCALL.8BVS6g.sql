create PROCEDURE testCall(
v1 in out number,
v2 in number:=100,
v3 out number)
IS
BEGIN
 v3:=v1+v2;
 v1:=100;
END testCall;
/

