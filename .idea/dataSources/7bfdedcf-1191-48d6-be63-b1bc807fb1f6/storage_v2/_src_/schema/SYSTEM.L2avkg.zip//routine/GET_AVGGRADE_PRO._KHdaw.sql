create procedure get_avggrade_pro(p_sno in student .sno%type,p_avg out student.savggrade%type)
as
v_avg(grade) sc.grade%TYPE;
begin
select avg(grade) into p_avg from sc where sc.sno=p_sno;
dbms_output.put_line(v_avg(grade));
end;
/

