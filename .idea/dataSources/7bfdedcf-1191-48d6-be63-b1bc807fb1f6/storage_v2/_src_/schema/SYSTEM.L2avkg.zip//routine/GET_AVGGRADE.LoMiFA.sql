create procedure get_avggrade-pro(p_sno in student.sno%type,p_avg out student.savggrade%type)
as
begin
select avg(grade)into p_acg from sc where sno="9512101";
end;
/

