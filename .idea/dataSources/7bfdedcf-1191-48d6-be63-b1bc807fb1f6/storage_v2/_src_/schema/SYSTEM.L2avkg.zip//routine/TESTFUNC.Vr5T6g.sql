create FUNCTION testFunc(
v1 in out number,
v2 in number:=100,
v3 out number)
RETURN number
AS
 Result number;
BEGIN
 v1:=v2+v1;
 v3:=v2+55;
 Result:=v1+v2+v3;
 return(Result);
END TESTFUNC;
/

