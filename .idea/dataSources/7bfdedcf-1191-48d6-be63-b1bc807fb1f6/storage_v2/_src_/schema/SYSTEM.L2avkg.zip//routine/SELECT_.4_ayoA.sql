create procedure select_
get_avggrade(p_sno in student .sno%type,p_avg out student.savggrade%type)
as
v_grade sc.grade%TYPE;
begin
select avg(grade) into v_avg(grade) from sc where sc.sno=p.sno;
dbms_output.put_line(v_grade);
end;
/

